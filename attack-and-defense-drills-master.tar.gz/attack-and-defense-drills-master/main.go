/**
 * File: main.go
 *
 * This code is for attack and defense drills and does not involve any
 * intellectual property rights. If it violates security requirements,
 * please contact rongtao@cestc.cn to delete it.
 *
 * 这段代码为攻防演练代码，不涉及任何知识产权，若有背安全要求，请联系
 * rongtao@cestc.cn 删除。
 *
 * Copyright (C) CESTC, Co. 2024. All rights reserved.
 */
package main

import (
	"fmt"
)

func main() {
	fmt.Println("Hello")
}
